using UnityEngine;
using UnityEngine.UI;
public class GameManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    public int coinsCounter = 0;
    public Text coinText;

    /* Update is called once per frame
    void Update()
    {
        coinText.text = coinsCounter.ToString();
    }*/
}
